package rsk

fun main(args: Array<String>) {
    println(max(1,2))
}

fun max(a: Int, b: Int): Int = if (a > b) a else b
