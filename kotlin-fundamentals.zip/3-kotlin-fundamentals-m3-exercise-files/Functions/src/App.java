import rsk.*;

public class App {
    public static void main(String[] args) {
        DisplayFunctions.log("Hello, World from Java");
        DisplayFunctions.log("Hello, World from Java", 3);
    }
}
