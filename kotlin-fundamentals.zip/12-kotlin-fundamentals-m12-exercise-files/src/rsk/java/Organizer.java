package rsk.java;

import java.util.List;

/**
 * Created by kevin on 02/02/2017.
 */
public interface Organizer {
    void processMeetings(List<Meeting> meetings);
}


