package rsk.java;

/**
 * Created by kevin on 02/02/2017.
 */
public class Meeting {
}
