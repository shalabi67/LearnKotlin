package rsk.java;

public interface Created {
    void onCreate(User user);
}
