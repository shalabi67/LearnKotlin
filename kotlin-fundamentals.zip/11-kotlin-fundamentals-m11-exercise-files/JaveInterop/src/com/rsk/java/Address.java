package com.rsk.java;


public interface Address {
    String getFirstAddress();
}
