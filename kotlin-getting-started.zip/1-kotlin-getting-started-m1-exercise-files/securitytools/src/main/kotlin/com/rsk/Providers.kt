package com.rsk

import java.security.Provider
import java.security.Security

/**
 * Created by kevin on 10/09/2016.
 */
class Providers {

    fun getProviders() : List<Provider> {
        val providers = Security.getProviders()
        val listOfProviders:List<Provider> = providers.asList()
        return listOfProviders
    }

    companion object {
        fun getProviders() : List<Provider> {
            val providers = Security.getProviders()
            val listOfProviders:List<Provider> = providers.asList()
            return listOfProviders
        }
    }
}